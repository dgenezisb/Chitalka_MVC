﻿CREATE TABLE [dbo].[Books] (
    [Id]       INT           NOT NULL,
    [Name]     NVARCHAR (50) NOT NULL,
    [Author]   INT           NULL,
    [genre]    INT           NULL,
    [cent]     INT           NULL,
    [country]  NVARCHAR (50) NULL,
    [descr]    TEXT NULL,
    [quote]    TEXT NOT NULL,
    [text]     NVARCHAR (50) NULL,
    [visiable] INT           NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    FOREIGN KEY ([Author]) REFERENCES [dbo].[Author] ([Id]),
    FOREIGN KEY ([genre]) REFERENCES [dbo].[Genre] ([Id])
);

