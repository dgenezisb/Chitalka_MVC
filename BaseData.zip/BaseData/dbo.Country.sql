﻿CREATE TABLE [dbo].[Country] (
    [Id]       INT           NOT NULL,
    [Name]     NVARCHAR (50) NULL,
    [authorid] INT           NULL,
    [bookid]   INT           NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    FOREIGN KEY ([authorid]) REFERENCES [dbo].[Author] ([Id]),
    FOREIGN KEY ([bookid]) REFERENCES [dbo].[Books] ([Id])
);

