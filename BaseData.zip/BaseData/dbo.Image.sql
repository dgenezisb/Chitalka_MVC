﻿CREATE TABLE [dbo].[Image] (
    [Id]       INT   NOT NULL,
	[bookid] int unique foreign key references dbo.Books(Id) NOT NULL,
    [smallimg] IMAGE NOT NULL,
    [bigimg]   IMAGE NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

