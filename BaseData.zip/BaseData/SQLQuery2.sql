﻿INSERT INTO Genre (Id, Name, bookid) VALUES (2001, N'драма', 0001)
