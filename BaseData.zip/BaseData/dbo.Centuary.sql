﻿CREATE TABLE [dbo].[Centuary] (
    [Id]     INT           NOT NULL,
    [Name]   NVARCHAR (50) NOT NULL,
    [bookid] INT           NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    FOREIGN KEY ([bookid]) REFERENCES [dbo].[Books] ([Id])
);

